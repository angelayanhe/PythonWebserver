#!/bin/bash
cd /tmp/CodeDeployExample

#python3 HTTPServerPY3.py > application-start.txt

echo "The ApplicationStart deployment lifecycle event successfully completed." > application-start.txt
